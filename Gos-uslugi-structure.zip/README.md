# Gos-uslugi — RP Telegram Mini App

Вымышленный портал для игрового RP-проекта. Не является официальным государственным сервисом.

## Структура

- `bot/` — Telegram-бот и backend API
- `web/` — Telegram Mini App
- `database/` — SQLite
- `docs/` — документация
- `.env.example` — настройки окружения
- `requirements.txt` — зависимости Python

## Запуск

```bash
python -m venv .venv
# Windows:
.venv\Scripts\activate
# Linux/macOS:
source .venv/bin/activate

pip install -r requirements.txt
python bot/main.py
```

Перед запуском укажите `BOT_TOKEN` и `WEB_APP_URL` в переменных окружения.

Mini App должен быть доступен по HTTPS.
