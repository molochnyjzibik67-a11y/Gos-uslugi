# Здесь будет API Mini App.
# Важно: Telegram initData должна проверяться на сервере
# через HMAC перед выполнением операций с аккаунтом пользователя.

from aiohttp import web


async def api_me(request):
    return web.json_response({"ok": True, "message": "API готово"})


async def api_dashboard(request):
    return web.json_response({
        "applications": [],
        "fines": [],
        "vehicles": []
    })


async def create_application(request):
    data = await request.json()

    return web.json_response({
        "ok": True,
        "service": data.get("service", "")
    })


def register_routes(app):
    app.router.add_get("/api/me", api_me)
    app.router.add_get("/api/dashboard", api_dashboard)
    app.router.add_post("/api/applications", create_application)
