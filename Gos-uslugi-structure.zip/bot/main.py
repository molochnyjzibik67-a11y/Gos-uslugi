import asyncio
import os
from pathlib import Path

from aiohttp import web
from aiogram import Bot, Dispatcher, types
from aiogram.filters import CommandStart
from aiogram.types import InlineKeyboardButton, InlineKeyboardMarkup, WebAppInfo
from dotenv import load_dotenv

from db import init_db

load_dotenv()

BOT_TOKEN = os.environ["BOT_TOKEN"]
WEB_APP_URL = os.environ["WEB_APP_URL"]
HOST = os.getenv("HOST", "0.0.0.0")
PORT = int(os.getenv("PORT", "8080"))

bot = Bot(BOT_TOKEN)
dp = Dispatcher()


@dp.message(CommandStart())
async def start(message: types.Message):
    keyboard = InlineKeyboardMarkup(inline_keyboard=[[
        InlineKeyboardButton(
            text="Открыть ГосПортал RP",
            web_app=WebAppInfo(url=WEB_APP_URL)
        )
    ]])

    await message.answer(
        "ГосПортал RP\n\n"
        "Вымышленный сервис игрового проекта. "
        "Не является официальным государственным сайтом.",
        reply_markup=keyboard
    )


async def health(request):
    return web.json_response({"ok": True})


async def index(request):
    return web.FileResponse(
        Path(__file__).resolve().parent.parent / "web" / "index.html"
    )


async def web_server():
    app = web.Application()
    app.router.add_get("/", index)
    app.router.add_get("/health", health)

    # API routes подключаются здесь:
    # app.router.add_get("/api/me", api_me)
    # app.router.add_get("/api/dashboard", api_dashboard)
    # app.router.add_post("/api/applications", create_application)

    runner = web.AppRunner(app)
    await runner.setup()
    site = web.TCPSite(runner, HOST, PORT)
    await site.start()

    while True:
        await asyncio.sleep(3600)


async def main():
    init_db()
    await asyncio.gather(
        dp.start_polling(bot),
        web_server()
    )


if __name__ == "__main__":
    asyncio.run(main())
