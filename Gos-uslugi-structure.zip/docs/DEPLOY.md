# Развёртывание

1. Загрузить проект в GitHub.
2. Развернуть Python-приложение на сервере/хостинге.
3. Создать `.env` на сервере.
4. Указать `BOT_TOKEN`.
5. Указать HTTPS-адрес Mini App в `WEB_APP_URL`.
6. Запустить `python bot/main.py`.
7. Открыть `/start` у Telegram-бота.

Для production рекомендуется использовать HTTPS reverse proxy.
